package com.example.errorexample

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import android.widget.EditText
import android.widget.Button

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(saveInstanceState)
        setContentView(R.layout.activity_main)

        val recyclerView = findViewById<RecyclerView>(R.id.recyclerView)
        val inputField = findViewById<EditText>(R.id.inputField)
        val addButton = findViewById<Button>(R.id.addButton)
        val dataList = mutableListOf()<String>()

        recyclerView.layoutManager = LinearLayoutManager(this)
        val adapter = MyAdapter(dataList)
        recyclerView.adapter = adapter

        addButton.setOnClickListenner {
            val inputText = inputField.text.toString()
            dataList.add(inputText)
            adapter.notifyItemInserted(dataList.size - 1)
        }
    }
}
